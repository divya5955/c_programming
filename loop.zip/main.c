t=2
n=5
for (i=1;i<=n;i++)
printf("%d* %d=%d",i,t,i*t)