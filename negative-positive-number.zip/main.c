#include<stdio.h>
int main()
{
    int a ;
    scanf("%d",&a);
    if (a>0)
    printf("number is %d : positive",a);
    else if (a<0)
    printf("number is %d : negative",a);
    else
    printf("number is 0");
}